package com.aforotanque2026;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText diameterInput, lengthInput, levelInput;
    TextView resultText;
    LinearLayout tableContainer;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24,24,24,24);
        scroll.addView(main);

        TextView title = new TextView(this);
        title.setText("Calculadora de aforo de tanque");
        title.setTextSize(24); title.setTypeface(null, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        main.addView(title);

        TextView info = new TextView(this);
        info.setText("Tanque cilíndrico horizontal • tabla cada 1 cm • sin Internet");
        info.setTextSize(15); info.setPadding(0,12,0,18); main.addView(info);

        diameterInput = field("Diámetro del tanque (cm)", "200");
        lengthInput = field("Largo del tanque (cm)", "300");
        levelInput = field("Altura del líquido (cm)", "100");
        main.addView(diameterInput); main.addView(lengthInput); main.addView(levelInput);

        Button calculate = new Button(this); calculate.setText("CALCULAR"); main.addView(calculate);
        resultText = new TextView(this); resultText.setTextSize(18); resultText.setPadding(0,15,0,15); main.addView(resultText);
        Button table = new Button(this); table.setText("GENERAR TABLA DE AFORO"); main.addView(table);
        tableContainer = new LinearLayout(this); tableContainer.setOrientation(LinearLayout.VERTICAL); main.addView(tableContainer);

        calculate.setOnClickListener(v -> calculateLevel());
        table.setOnClickListener(v -> generateTable());
        setContentView(scroll);
        calculateLevel();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(17);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); e.setSingleLine(true);
        e.setPadding(8,12,8,12); return e;
    }

    private double val(EditText e) { return Double.parseDouble(e.getText().toString().replace(',','.')); }

    // Segmento circular en cm², multiplicado por largo en cm y convertido a litros.
    private double litersAt(double d, double l, double h) {
        double r=d/2.0;
        if(h<=0) return 0;
        if(h>=d) return Math.PI*r*r*l/1000.0;
        double y=h-r;
        double area=r*r*Math.acos(-y/r)+y*Math.sqrt(Math.max(0,r*r-y*y));
        return area*l/1000.0;
    }

    private void calculateLevel() {
        try {
            double d=val(diameterInput), l=val(lengthInput), h=val(levelInput);
            if(d<=0 || l<=0 || h<0 || h>d) throw new Exception();
            double liters=litersAt(d,l,h), total=litersAt(d,l,d);
            resultText.setText(String.format(Locale.US,"Volumen: %.2f litros\nCapacidad total: %.2f litros\nLlenado: %.2f %%",liters,total,liters*100/total));
        } catch(Exception e) { resultText.setText("Revisa las medidas. La altura debe estar entre 0 y el diámetro."); }
    }

    private void generateTable() {
        tableContainer.removeAllViews();
        try {
            double d=val(diameterInput), l=val(lengthInput);
            if(d<=0 || l<=0 || d>10000 || l>10000) throw new Exception();
            TextView header=new TextView(this); header.setText("ALTURA (cm)                         LITROS"); header.setTypeface(null,Typeface.BOLD); header.setTextSize(16); header.setPadding(8,12,8,12); tableContainer.addView(header);
            int max=(int)Math.floor(d);
            for(int h=0; h<=max; h++) {
                TextView row=new TextView(this); row.setText(String.format(Locale.US,"%4d cm                              %.2f L",h,litersAt(d,l,h))); row.setTextSize(15); row.setPadding(8,7,8,7); tableContainer.addView(row);
            }
        } catch(Exception e) { TextView error=new TextView(this); error.setText("Introduce diámetro y largo válidos."); tableContainer.addView(error); }
    }
}
