# AforoTanque2026

Proyecto Android offline para aforo de tanques cilíndricos horizontales.

- Diámetro y largo configurables.
- Tabla automática cada 1 cm hasta el diámetro.
- Cálculo de litros y porcentaje de llenado.
- Sin Internet y sin permisos de red.
- Java, sin Kotlin.
- minSdk 21.
- La aplicación usa código Java y no incluye bibliotecas nativas propias, por lo que el APK es apto para dispositivos ARMv7 que soporten la versión mínima de Android.
